import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/book_appointment/book_appointment_bloc.dart';
import '../bloc/book_appointment/book_appointment_event.dart';
import '../bloc/book_appointment/book_appointment_state.dart';

class BookAppointmentScreen extends StatelessWidget {
  final String doctorId;

  BookAppointmentScreen({required this.doctorId});

  @override
  Widget build(BuildContext context) {
    final bookAppointmentBloc = BlocProvider.of<BookAppointmentBloc>(context);

    return Scaffold(
      appBar: AppBar(title: Text('Book Appointment')),
      body: BlocBuilder<BookAppointmentBloc, BookAppointmentState>(
        builder: (context, state) {
          if (state is BookAppointmentLoading) {
            return Center(child: CircularProgressIndicator());
          } else if (state is BookAppointmentSuccess) {
            return Center(child: Text('Appointment booked successfully!'));
          } else if (state is BookAppointmentFailure) {
            return Center(child: Text('Failed to book appointment: ${state.error}'));
          }

          return Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () {
                    bookAppointmentBloc.add(ConfirmAppointment(doctorId));
                  },
                  child: Text('Confirm Appointment'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
