part of 'patient_bloc.dart';

abstract class PatientEvent extends Equatable {
  const PatientEvent();

  @override
  List<Object> get props => [];
}

class FetchPatientDetails extends PatientEvent {
  final String patientId;

  const FetchPatientDetails({required this.patientId});

  @override
  List<Object> get props => [patientId];
}
