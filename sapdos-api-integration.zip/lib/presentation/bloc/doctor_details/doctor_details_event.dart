import 'package:equatable/equatable.dart';

abstract class DoctorDetailsEvent extends Equatable {
  const DoctorDetailsEvent();

  @override
  List<Object> get props => [];
}

class FetchDoctorDetails extends DoctorDetailsEvent {
  final String doctorId;

  FetchDoctorDetails({required this.doctorId});

  @override
  List<Object> get props => [doctorId];
}
