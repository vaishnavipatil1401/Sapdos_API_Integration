import 'package:sapdos_api_integration_assignment/data/models/patient.dart';
import 'package:sapdos_api_integration_assignment/data/repositories/api_service.dart';

class GetPatientUseCase {
  final ApiService apiService;

  GetPatientUseCase({required this.apiService});

  Future<Patient> call(String patientId) async {
    final response = await apiService.getPatientDetails(patientId);
    return response;
  }
}
